<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PageController;

Route::get('/', [PageController::class, 'beranda'])->name('beranda');
Route::get('/profil', [PageController::class, 'profil'])->name('profil');
Route::get('/berita', [PageController::class, 'berita'])->name('berita');
Route::get('/pengurus', [PageController::class, 'pengurus'])->name('pengurus');
Route::get('/kontak', [PageController::class, 'kontak'])->name('kontak');
