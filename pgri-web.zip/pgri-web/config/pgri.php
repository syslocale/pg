<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Identitas Daerah
    |--------------------------------------------------------------------------
    | Semua nilai diambil dari .env — cukup ubah .env untuk setiap daerah.
    */

    'daerah'    => env('PGRI_DAERAH', 'Daerah'),
    'provinsi'  => env('PGRI_PROVINSI', ''),
    'singkatan' => env('PGRI_SINGKATAN', 'PGRI Daerah'),

    /*
    |--------------------------------------------------------------------------
    | Kontak
    |--------------------------------------------------------------------------
    */

    'alamat'    => env('PGRI_ALAMAT', '-'),
    'kota'      => env('PGRI_KOTA', '-'),
    'kode_pos'  => env('PGRI_KODE_POS', ''),
    'telepon'   => env('PGRI_TELEPON', '-'),
    'email'     => env('PGRI_EMAIL', '-'),
    'website'   => env('PGRI_WEBSITE', '#'),
    'maps_url'  => env('PGRI_MAPS_URL', '#'),

    /*
    |--------------------------------------------------------------------------
    | Statistik
    |--------------------------------------------------------------------------
    */

    'anggota'       => env('PGRI_JUMLAH_ANGGOTA', '-'),
    'cabang'        => env('PGRI_JUMLAH_CABANG', '-'),
    'tahun_berdiri' => env('PGRI_TAHUN_BERDIRI', '1945'),

    /*
    |--------------------------------------------------------------------------
    | Media Sosial
    |--------------------------------------------------------------------------
    */

    'sosmed' => [
        'facebook'  => env('PGRI_FACEBOOK', ''),
        'instagram' => env('PGRI_INSTAGRAM', ''),
        'youtube'   => env('PGRI_YOUTUBE', ''),
    ],

];
