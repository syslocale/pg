<?php

/*
|--------------------------------------------------------------------------
| Data Pengurus Pusat PGRI
|--------------------------------------------------------------------------
| Data ini berlaku untuk semua daerah — pengurus pusat sama di mana-mana.
| Untuk memperbarui, cukup edit file ini satu kali.
*/

return [

    'periode' => '2024–2029',

    'dewan_pengurus' => [
        [
            'nama'   => 'Prof. Dr. Unifah Rosyidi, M.Pd',
            'jabatan'=> 'Ketua Umum',
            'asal'   => 'DKI Jakarta',
            'inisial'=> 'UR',
            'warna'  => 'biru',
        ],
        [
            'nama'   => 'Dudung Nurullah Koswara, M.Pd',
            'jabatan'=> 'Sekretaris Jenderal',
            'asal'   => 'Jawa Barat',
            'inisial'=> 'DN',
            'warna'  => 'hijau',
        ],
        [
            'nama'   => 'Drs. H. Pepen Permana, M.M',
            'jabatan'=> 'Bendahara Umum',
            'asal'   => 'Jawa Barat',
            'inisial'=> 'PP',
            'warna'  => 'kuning',
        ],
        [
            'nama'   => 'Dr. Jejen Musfah, M.A',
            'jabatan'=> 'Wakil Ketua Umum I',
            'asal'   => 'DKI Jakarta',
            'inisial'=> 'JM',
            'warna'  => 'merah',
        ],
        [
            'nama'   => 'Dr. Hj. Noor Rakhmat, M.Pd',
            'jabatan'=> 'Wakil Ketua Umum II',
            'asal'   => 'Kalimantan Selatan',
            'inisial'=> 'NR',
            'warna'  => 'ungu',
        ],
        [
            'nama'   => 'Drs. H. Sahat Sinaga, M.M',
            'jabatan'=> 'Wakil Sekretaris Jenderal',
            'asal'   => 'Sumatera Utara',
            'inisial'=> 'SS',
            'warna'  => 'biru',
        ],
    ],

];
