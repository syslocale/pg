@extends('layouts.app')
@section('title', 'Profil Organisasi')

@section('content')

<div class="bg-pgri-800 py-14 px-4 text-center text-white">
    <p class="text-xs uppercase tracking-widest text-white/40 mb-2">Tentang Kami</p>
    <h1 class="font-display text-4xl mb-3">Profil Organisasi</h1>
    <p class="text-white/60 text-sm">PGRI {{ $pgri['daerah'] }}, {{ $pgri['provinsi'] }}</p>
</div>

<div class="max-w-4xl mx-auto px-4 py-14 space-y-12">

    {{-- Sejarah Singkat --}}
    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-8">
        <h2 class="font-display text-2xl text-pgri-900 mb-4">Sejarah Singkat</h2>
        <p class="text-gray-600 leading-relaxed mb-4">
            Persatuan Guru Republik Indonesia (PGRI) didirikan pada tanggal 25 November 1945, seratus hari setelah Indonesia merdeka.
            Lahir dari semangat kemerdekaan, PGRI merupakan wadah perjuangan para guru dalam memajukan pendidikan nasional.
        </p>
        <p class="text-gray-600 leading-relaxed">
            PGRI {{ $pgri['daerah'] }} hadir sebagai bagian dari gerakan besar ini, berdedikasi untuk meningkatkan
            kualitas pendidikan dan kesejahteraan guru di seluruh wilayah {{ $pgri['daerah'] }}, {{ $pgri['provinsi'] }}.
        </p>
    </div>

    {{-- Visi & Misi --}}
    <div class="grid md:grid-cols-2 gap-6">
        <div class="bg-pgri-800 text-white rounded-2xl p-8">
            <h2 class="font-display text-xl mb-4">Visi</h2>
            <p class="text-white/75 leading-relaxed text-sm">
                Terwujudnya organisasi PGRI yang mandiri, dinamis, dan berwibawa sebagai wahana untuk meningkatkan
                profesionalitas dan kesejahteraan guru demi terwujudnya pendidikan nasional yang bermutu.
            </p>
        </div>
        <div class="bg-accent-500 text-white rounded-2xl p-8">
            <h2 class="font-display text-xl mb-4">Misi</h2>
            <ul class="space-y-2 text-white/90 text-sm leading-relaxed">
                <li class="flex gap-2"><span class="mt-0.5">→</span> Meningkatkan keimanan dan ketakwaan anggota</li>
                <li class="flex gap-2"><span class="mt-0.5">→</span> Membela dan melindungi hak guru</li>
                <li class="flex gap-2"><span class="mt-0.5">→</span> Meningkatkan kompetensi dan profesionalisme</li>
                <li class="flex gap-2"><span class="mt-0.5">→</span> Memajukan pendidikan nasional</li>
            </ul>
        </div>
    </div>

    {{-- Statistik --}}
    <div class="grid grid-cols-3 gap-6">
        @foreach([
            ['label' => 'Anggota Aktif', 'nilai' => $pgri['anggota'], 'sub' => 'Guru terdaftar'],
            ['label' => 'Cabang',        'nilai' => $pgri['cabang'],  'sub' => 'Kecamatan'],
            ['label' => 'Berdiri Sejak', 'nilai' => $pgri['tahun_berdiri'], 'sub' => 'Tahun'],
        ] as $stat)
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 text-center">
            <p class="font-display text-3xl text-pgri-800 mb-1">{{ $stat['nilai'] }}</p>
            <p class="font-medium text-sm text-gray-700">{{ $stat['label'] }}</p>
            <p class="text-xs text-gray-400">{{ $stat['sub'] }}</p>
        </div>
        @endforeach
    </div>

</div>
@endsection
