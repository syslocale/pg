@extends('layouts.app')
@section('title', 'Kontak')

@section('content')

<div class="bg-pgri-800 py-14 px-4 text-center text-white">
    <p class="text-xs uppercase tracking-widest text-white/40 mb-2">Hubungi Kami</p>
    <h1 class="font-display text-4xl mb-3">Kontak</h1>
    <p class="text-white/60 text-sm">PGRI {{ $pgri['daerah'] }}</p>
</div>

<div class="max-w-5xl mx-auto px-4 py-14 grid md:grid-cols-2 gap-10">

    {{-- Info Kontak --}}
    <div class="space-y-6">
        <h2 class="font-display text-2xl text-pgri-900">Informasi Kontak</h2>

        @foreach([
            ['ikon' => '📍', 'label' => 'Alamat', 'nilai' => $pgri['alamat'] . ', ' . $pgri['kota'] . ' ' . $pgri['kode_pos']],
            ['ikon' => '📞', 'label' => 'Telepon', 'nilai' => $pgri['telepon']],
            ['ikon' => '✉️', 'label' => 'Email',   'nilai' => $pgri['email']],
            ['ikon' => '🌐', 'label' => 'Website', 'nilai' => $pgri['website']],
        ] as $info)
        <div class="flex gap-4 bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
            <span class="text-2xl">{{ $info['ikon'] }}</span>
            <div>
                <p class="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-0.5">{{ $info['label'] }}</p>
                <p class="text-gray-800 text-sm">{{ $info['nilai'] }}</p>
            </div>
        </div>
        @endforeach

        @if($pgri['maps_url'] && $pgri['maps_url'] !== '#')
        <a href="{{ $pgri['maps_url'] }}" target="_blank"
           class="inline-block bg-pgri-800 hover:bg-pgri-700 text-white text-sm font-medium px-5 py-2.5 rounded-lg transition-colors">
            Lihat di Google Maps →
        </a>
        @endif
    </div>

    {{-- Form Kontak --}}
    <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-8">
        <h2 class="font-display text-xl text-pgri-900 mb-6">Kirim Pesan</h2>

        <form class="space-y-4" action="#" method="POST">
            @csrf
            <div>
                <label class="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Nama Lengkap</label>
                <input type="text" name="nama" required
                       class="w-full border border-gray-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-pgri-400"
                       placeholder="Nama Anda">
            </div>
            <div>
                <label class="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Email</label>
                <input type="email" name="email" required
                       class="w-full border border-gray-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-pgri-400"
                       placeholder="email@contoh.com">
            </div>
            <div>
                <label class="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Pesan</label>
                <textarea name="pesan" rows="4" required
                          class="w-full border border-gray-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-pgri-400 resize-none"
                          placeholder="Tulis pesan Anda di sini..."></textarea>
            </div>
            <button type="submit"
                    class="w-full bg-pgri-800 hover:bg-pgri-700 text-white font-medium py-2.5 rounded-lg text-sm transition-colors">
                Kirim Pesan
            </button>
        </form>
    </div>

</div>
@endsection
