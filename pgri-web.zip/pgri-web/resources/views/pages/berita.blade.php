@extends('layouts.app')
@section('title', 'Berita & Pengumuman')

@section('content')

<div class="bg-pgri-800 py-14 px-4 text-center text-white">
    <p class="text-xs uppercase tracking-widest text-white/40 mb-2">Informasi Terkini</p>
    <h1 class="font-display text-4xl mb-3">Berita & Pengumuman</h1>
    <p class="text-white/60 text-sm">PGRI {{ $pgri['daerah'] }}</p>
</div>

<div class="max-w-5xl mx-auto px-4 py-14">

    {{-- Filter kategori (UI only) --}}
    <div class="flex flex-wrap gap-2 mb-10">
        @foreach(['Semua', 'Kegiatan', 'Organisasi', 'Advokasi', 'Beasiswa', 'HUT PGRI'] as $kat)
        <button class="text-xs px-4 py-1.5 rounded-full border border-pgri-200 text-pgri-700 hover:bg-pgri-800 hover:text-white hover:border-pgri-800 transition-all
            {{ $loop->first ? 'bg-pgri-800 text-white border-pgri-800' : '' }}">
            {{ $kat }}
        </button>
        @endforeach
    </div>

    <div class="grid md:grid-cols-2 gap-6">
        @foreach($berita as $item)
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden hover:shadow-md transition-shadow">
            <div class="h-36 bg-pgri-50 flex items-center justify-center border-b border-gray-50">
                <span class="font-display text-5xl text-pgri-200">{{ substr($item['kategori'], 0, 1) }}</span>
            </div>
            <div class="p-5">
                <div class="flex items-center gap-2 mb-3">
                    <span class="text-[10px] font-semibold bg-pgri-50 text-pgri-600 px-2 py-0.5 rounded uppercase tracking-wide">
                        {{ $item['kategori'] }}
                    </span>
                    @if($item['utama'])
                    <span class="text-[10px] font-semibold bg-accent-100 text-amber-700 px-2 py-0.5 rounded uppercase tracking-wide">
                        Utama
                    </span>
                    @endif
                </div>
                <h3 class="font-semibold text-gray-900 leading-snug mb-2">{{ $item['judul'] }}</h3>
                <p class="text-sm text-gray-500 mb-4 leading-relaxed">{{ $item['ringkasan'] }}</p>
                <div class="flex items-center justify-between">
                    <p class="text-xs text-gray-400">{{ $item['tanggal'] }}</p>
                    <a href="#" class="text-xs text-pgri-600 font-medium hover:underline">Baca selengkapnya →</a>
                </div>
            </div>
        </div>
        @endforeach
    </div>

</div>
@endsection
