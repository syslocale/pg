@extends('layouts.app')
@section('title', 'Beranda')

@section('content')

{{-- HERO --}}
<section class="bg-gradient-to-br from-pgri-900 via-pgri-800 to-pgri-700 text-white py-20 px-4">
    <div class="max-w-3xl mx-auto text-center">
        <span class="inline-block bg-accent-500 text-white text-xs font-semibold px-3 py-1 rounded-full mb-4 uppercase tracking-wide">
            Website Resmi
        </span>
        <h1 class="font-display text-4xl md:text-5xl leading-tight mb-4">
            PGRI {{ $pgri['daerah'] }}
        </h1>
        <p class="text-white/65 text-base mb-2">{{ $pgri['provinsi'] }}</p>
        <p class="text-white/80 text-lg mb-8">Bersatu · Berjuang · Berdedikasi untuk Pendidikan Indonesia</p>

        <div class="flex flex-col sm:flex-row gap-3 justify-center">
            <a href="{{ route('berita') }}"
               class="bg-accent-500 hover:bg-accent-400 text-white font-medium px-6 py-3 rounded-lg text-sm transition-colors">
                Baca Berita Terkini
            </a>
            <a href="{{ route('kontak') }}"
               class="border border-white/30 hover:bg-white/10 text-white font-medium px-6 py-3 rounded-lg text-sm transition-colors">
                Hubungi Kami
            </a>
        </div>
    </div>
</section>

{{-- STATISTIK --}}
<section class="bg-white border-b border-gray-100">
    <div class="max-w-6xl mx-auto px-4 py-8 grid grid-cols-3 divide-x divide-gray-100">
        <div class="text-center px-4">
            <p class="font-display text-3xl text-pgri-800">{{ $pgri['anggota'] }}</p>
            <p class="text-xs text-gray-400 mt-1 uppercase tracking-wide">Anggota Aktif</p>
        </div>
        <div class="text-center px-4">
            <p class="font-display text-3xl text-pgri-800">{{ $pgri['cabang'] }}</p>
            <p class="text-xs text-gray-400 mt-1 uppercase tracking-wide">Cabang</p>
        </div>
        <div class="text-center px-4">
            <p class="font-display text-3xl text-pgri-800">{{ $pgri['tahun_berdiri'] }}</p>
            <p class="text-xs text-gray-400 mt-1 uppercase tracking-wide">Berdiri Sejak</p>
        </div>
    </div>
</section>

{{-- BERITA TERKINI --}}
<section class="max-w-6xl mx-auto px-4 py-14">
    <div class="flex items-center justify-between mb-8">
        <h2 class="font-display text-2xl text-pgri-900 border-l-4 border-accent-500 pl-4">Berita Terkini</h2>
        <a href="{{ route('berita') }}" class="text-pgri-600 text-sm hover:underline">Lihat semua →</a>
    </div>

    @php $utama = collect($berita)->firstWhere('utama', true); @endphp
    @php $lainnya = collect($berita)->where('utama', false)->take(4); @endphp

    <div class="grid md:grid-cols-5 gap-6">

        {{-- Berita Utama --}}
        @if($utama)
        <div class="md:col-span-3 bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
            <div class="h-52 bg-pgri-100 flex items-center justify-center">
                <span class="text-pgri-300 text-5xl font-display">{{ substr($utama['kategori'], 0, 1) }}</span>
            </div>
            <div class="p-6">
                <span class="inline-block text-[10px] font-semibold bg-pgri-50 text-pgri-700 px-2 py-0.5 rounded uppercase tracking-wide mb-3">
                    {{ $utama['kategori'] }}
                </span>
                <h3 class="font-semibold text-gray-900 text-lg leading-snug mb-2">{{ $utama['judul'] }}</h3>
                <p class="text-gray-500 text-sm mb-3">{{ $utama['ringkasan'] }}</p>
                <p class="text-xs text-gray-400">{{ $utama['tanggal'] }}</p>
            </div>
        </div>
        @endif

        {{-- Berita Lainnya --}}
        <div class="md:col-span-2 flex flex-col gap-3">
            @foreach($lainnya as $item)
            <div class="bg-white rounded-xl border border-gray-100 p-4 hover:shadow-sm transition-shadow cursor-pointer">
                <div class="flex items-start gap-3">
                    <span class="w-2 h-2 rounded-full bg-accent-500 mt-1.5 shrink-0"></span>
                    <div>
                        <p class="text-sm font-medium text-gray-800 leading-snug">{{ $item['judul'] }}</p>
                        <p class="text-xs text-gray-400 mt-1">{{ $item['tanggal'] }} · {{ $item['kategori'] }}</p>
                    </div>
                </div>
            </div>
            @endforeach
        </div>

    </div>
</section>

{{-- TENTANG SINGKAT --}}
<section class="bg-pgri-800 text-white py-16 px-4">
    <div class="max-w-3xl mx-auto text-center">
        <p class="text-xs uppercase tracking-widest text-white/40 mb-3">Tentang Kami</p>
        <h2 class="font-display text-3xl mb-5">Organisasi Guru Terbesar di Indonesia</h2>
        <p class="text-white/70 text-base leading-relaxed mb-8">
            PGRI {{ $pgri['daerah'] }} adalah bagian dari Persatuan Guru Republik Indonesia yang berdiri sejak {{ $pgri['tahun_berdiri'] }}.
            Kami hadir untuk memperjuangkan hak, kesejahteraan, dan profesionalisme guru di seluruh wilayah
            {{ $pgri['daerah'] }}, {{ $pgri['provinsi'] }}.
        </p>
        <a href="{{ route('profil') }}"
           class="inline-block border border-white/30 hover:bg-white/10 text-white font-medium px-6 py-3 rounded-lg text-sm transition-colors">
            Selengkapnya →
        </a>
    </div>
</section>

@endsection
