@extends('layouts.app')
@section('title', 'Pengurus Pusat')

@php
$warnaBadge = [
    'biru'   => 'bg-blue-100 text-blue-800',
    'hijau'  => 'bg-green-100 text-green-800',
    'kuning' => 'bg-amber-100 text-amber-800',
    'merah'  => 'bg-red-100 text-red-800',
    'ungu'   => 'bg-purple-100 text-purple-800',
];
$warnaInisial = [
    'biru'   => 'bg-pgri-100 text-pgri-700',
    'hijau'  => 'bg-green-100 text-green-700',
    'kuning' => 'bg-amber-100 text-amber-700',
    'merah'  => 'bg-red-100 text-red-700',
    'ungu'   => 'bg-purple-100 text-purple-700',
];
@endphp

@section('content')

<div class="bg-pgri-800 py-14 px-4 text-center text-white">
    <p class="text-xs uppercase tracking-widest text-white/40 mb-2">Struktur Organisasi</p>
    <h1 class="font-display text-4xl mb-3">Pengurus Pusat PGRI</h1>
    <p class="text-white/60 text-sm">Periode {{ $pengurus['periode'] }}</p>
</div>

<div class="max-w-5xl mx-auto px-4 py-14">

    <p class="text-center text-gray-500 text-sm mb-10">
        Data pengurus pusat berlaku untuk seluruh daerah PGRI di Indonesia.
    </p>

    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        @foreach($pengurus['dewan_pengurus'] as $p)
        <div class="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 flex flex-col items-center text-center hover:shadow-md transition-shadow">

            <div class="w-16 h-16 rounded-full {{ $warnaInisial[$p['warna']] ?? 'bg-gray-100 text-gray-600' }} flex items-center justify-center font-display font-semibold text-xl mb-4">
                {{ $p['inisial'] }}
            </div>

            <p class="font-semibold text-gray-900 text-sm leading-snug mb-1">{{ $p['nama'] }}</p>
            <p class="text-xs text-gray-400 mb-3">{{ $p['asal'] }}</p>

            <span class="text-[11px] font-semibold px-3 py-1 rounded-full {{ $warnaBadge[$p['warna']] ?? 'bg-gray-100 text-gray-600' }}">
                {{ $p['jabatan'] }}
            </span>

        </div>
        @endforeach
    </div>

    <div class="mt-12 bg-pgri-50 border border-pgri-100 rounded-2xl p-6 text-center">
        <p class="text-sm text-pgri-700 font-medium mb-1">Data pengurus pusat dikelola di <code class="bg-pgri-100 px-1.5 py-0.5 rounded text-pgri-800">config/pengurus.php</code></p>
        <p class="text-xs text-pgri-500">Untuk memperbarui, edit file tersebut — perubahan langsung berlaku di semua halaman.</p>
    </div>

</div>
@endsection
