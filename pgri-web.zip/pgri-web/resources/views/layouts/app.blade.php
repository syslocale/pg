<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $title ?? 'Beranda' }} — PGRI {{ $pgri['daerah'] }}</title>
    <meta name="description" content="Website Resmi PGRI {{ $pgri['daerah'] }}, {{ $pgri['provinsi'] }}">

    {{-- Google Fonts --}}
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600&family=Lora:wght@600&display=swap" rel="stylesheet">

    {{-- Tailwind CDN (ganti dengan Vite + npm di production) --}}
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        pgri: {
                            900: '#0f2a5e',
                            800: '#1a3a6b',
                            700: '#1e4a8a',
                            600: '#2d5fa3',
                            400: '#5b8fd4',
                            100: '#dde8f5',
                            50:  '#f0f5fc',
                        },
                        accent: {
                            500: '#f4a623',
                            400: '#f7bc52',
                            100: '#fef3dc',
                        }
                    },
                    fontFamily: {
                        sans:    ['"Plus Jakarta Sans"', 'sans-serif'],
                        display: ['Lora', 'serif'],
                    }
                }
            }
        }
    </script>

    <style>
        [x-cloak] { display: none !important; }
        .nav-link { @apply text-white/75 hover:text-white text-sm transition-colors; }
        .nav-link.active { @apply text-white font-medium border-b-2 border-accent-500 pb-0.5; }
    </style>
</head>
<body class="bg-pgri-50 font-sans text-gray-800 antialiased">

{{-- NAVBAR --}}
<nav class="bg-pgri-800 sticky top-0 z-50 shadow-md">
    <div class="max-w-6xl mx-auto px-4 flex items-center justify-between h-16">

        {{-- Brand --}}
        <a href="{{ route('beranda') }}" class="flex items-center gap-3">
            <div class="w-9 h-9 rounded-full bg-white flex items-center justify-center">
                <span class="text-pgri-800 font-display font-semibold text-xs leading-tight text-center">PGRI</span>
            </div>
            <div class="leading-tight">
                <p class="text-white font-semibold text-sm">PGRI {{ $pgri['daerah'] }}</p>
                <p class="text-white/50 text-[11px]">{{ $pgri['provinsi'] }}</p>
            </div>
        </a>

        {{-- Desktop Nav --}}
        <div class="hidden md:flex items-center gap-6">
            <a href="{{ route('beranda') }}"  class="nav-link {{ request()->routeIs('beranda')  ? 'active' : '' }}">Beranda</a>
            <a href="{{ route('profil') }}"   class="nav-link {{ request()->routeIs('profil')   ? 'active' : '' }}">Profil</a>
            <a href="{{ route('berita') }}"   class="nav-link {{ request()->routeIs('berita')   ? 'active' : '' }}">Berita</a>
            <a href="{{ route('pengurus') }}" class="nav-link {{ request()->routeIs('pengurus') ? 'active' : '' }}">Pengurus</a>
            <a href="{{ route('kontak') }}"   class="nav-link {{ request()->routeIs('kontak')   ? 'active' : '' }}">Kontak</a>
        </div>

        {{-- Mobile hamburger (simple) --}}
        <button id="menu-toggle" class="md:hidden text-white p-1">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
            </svg>
        </button>
    </div>

    {{-- Mobile menu --}}
    <div id="mobile-menu" class="hidden md:hidden bg-pgri-900 px-4 pb-4">
        <a href="{{ route('beranda') }}"  class="block py-2 text-white/80 text-sm">Beranda</a>
        <a href="{{ route('profil') }}"   class="block py-2 text-white/80 text-sm">Profil</a>
        <a href="{{ route('berita') }}"   class="block py-2 text-white/80 text-sm">Berita</a>
        <a href="{{ route('pengurus') }}" class="block py-2 text-white/80 text-sm">Pengurus</a>
        <a href="{{ route('kontak') }}"   class="block py-2 text-white/80 text-sm">Kontak</a>
    </div>
</nav>

{{-- TICKER PENGUMUMAN --}}
<div class="bg-accent-100 border-b border-accent-500/30 py-2 px-4 flex items-center gap-3 overflow-hidden">
    <span class="shrink-0 bg-accent-500 text-white text-[10px] font-semibold px-2 py-0.5 rounded-full uppercase tracking-wide">Info</span>
    <p class="text-xs text-amber-800 truncate">
        Selamat datang di website resmi PGRI {{ $pgri['daerah'] }} —
        {{ $pgri['telepon'] }} | {{ $pgri['email'] }}
    </p>
</div>

{{-- CONTENT --}}
<main>
    @yield('content')
</main>

{{-- FOOTER --}}
<footer class="bg-pgri-900 text-white mt-16">
    <div class="max-w-6xl mx-auto px-4 py-10 grid md:grid-cols-3 gap-8">

        <div>
            <p class="font-display text-lg mb-2">PGRI {{ $pgri['daerah'] }}</p>
            <p class="text-white/50 text-sm leading-relaxed">{{ $pgri['provinsi'] }}<br>Bersatu · Berjuang · Berdedikasi</p>
        </div>

        <div>
            <p class="text-xs font-semibold uppercase tracking-widest text-white/40 mb-3">Kontak</p>
            <ul class="space-y-1 text-sm text-white/70">
                <li>{{ $pgri['alamat'] }}</li>
                <li>{{ $pgri['kota'] }} {{ $pgri['kode_pos'] }}</li>
                <li class="pt-1">{{ $pgri['telepon'] }}</li>
                <li>{{ $pgri['email'] }}</li>
            </ul>
        </div>

        <div>
            <p class="text-xs font-semibold uppercase tracking-widest text-white/40 mb-3">Navigasi</p>
            <ul class="space-y-1 text-sm text-white/70">
                <li><a href="{{ route('beranda') }}"  class="hover:text-white transition-colors">Beranda</a></li>
                <li><a href="{{ route('profil') }}"   class="hover:text-white transition-colors">Profil Organisasi</a></li>
                <li><a href="{{ route('berita') }}"   class="hover:text-white transition-colors">Berita & Pengumuman</a></li>
                <li><a href="{{ route('pengurus') }}" class="hover:text-white transition-colors">Pengurus Pusat</a></li>
                <li><a href="{{ route('kontak') }}"   class="hover:text-white transition-colors">Kontak</a></li>
            </ul>
        </div>
    </div>

    <div class="border-t border-white/10 py-4 text-center text-xs text-white/30">
        © {{ date('Y') }} PGRI {{ $pgri['daerah'] }}. Dibangun dengan Laravel & Tailwind CSS.
    </div>
</footer>

<script>
    document.getElementById('menu-toggle').addEventListener('click', function () {
        document.getElementById('mobile-menu').classList.toggle('hidden');
    });
</script>

</body>
</html>
