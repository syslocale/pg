<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller
{
    private function pgri(): array
    {
        return config('pgri');
    }

    public function beranda()
    {
        $berita = $this->sampleBerita();

        return view('pages.beranda', [
            'pgri'   => $this->pgri(),
            'berita' => $berita,
        ]);
    }

    public function profil()
    {
        return view('pages.profil', [
            'pgri' => $this->pgri(),
        ]);
    }

    public function berita()
    {
        return view('pages.berita', [
            'pgri'   => $this->pgri(),
            'berita' => $this->sampleBerita(),
        ]);
    }

    public function pengurus()
    {
        return view('pages.pengurus', [
            'pgri'     => $this->pgri(),
            'pengurus' => config('pengurus'),
        ]);
    }

    public function kontak()
    {
        return view('pages.kontak', [
            'pgri' => $this->pgri(),
        ]);
    }

    // ----------------------------------------------------------------
    // Temporary sample data — ganti dengan Model + DB setelah siap
    // ----------------------------------------------------------------

    private function sampleBerita(): array
    {
        return [
            [
                'id'       => 1,
                'judul'    => 'PGRI Gelar Workshop Peningkatan Kompetensi Guru Se-Kabupaten',
                'kategori' => 'Kegiatan',
                'tanggal'  => '21 April 2026',
                'ringkasan'=> 'Ratusan guru mengikuti workshop intensif selama dua hari yang membahas strategi pembelajaran aktif dan pemanfaatan teknologi di kelas.',
                'utama'    => true,
            ],
            [
                'id'       => 2,
                'judul'    => 'Pelantikan Pengurus Periode 2025–2030 Berlangsung Khidmat',
                'kategori' => 'Organisasi',
                'tanggal'  => '18 April 2026',
                'ringkasan'=> 'Pelantikan dihadiri oleh Bupati dan jajaran Dinas Pendidikan setempat.',
                'utama'    => false,
            ],
            [
                'id'       => 3,
                'judul'    => 'Audiensi PGRI dengan Bupati Bahas Kesejahteraan Guru',
                'kategori' => 'Advokasi',
                'tanggal'  => '14 April 2026',
                'ringkasan'=> 'PGRI mendorong percepatan pencairan TPG dan perbaikan fasilitas sekolah.',
                'utama'    => false,
            ],
            [
                'id'       => 4,
                'judul'    => 'Program Beasiswa Guru 2026 Kini Dibuka',
                'kategori' => 'Beasiswa',
                'tanggal'  => '10 April 2026',
                'ringkasan'=> 'Pendaftaran beasiswa S2 bagi guru aktif anggota PGRI dibuka hingga 30 Mei 2026.',
                'utama'    => false,
            ],
            [
                'id'       => 5,
                'judul'    => 'HUT PGRI ke-81: Semangat Baru Pendidikan Bermutu',
                'kategori' => 'HUT PGRI',
                'tanggal'  => '25 November 2025',
                'ringkasan'=> 'Peringatan HUT diisi dengan serangkaian lomba, bakti sosial, dan malam apresiasi guru.',
                'utama'    => false,
            ],
        ];
    }
}
